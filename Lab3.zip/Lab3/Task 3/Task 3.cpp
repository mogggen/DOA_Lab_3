#include "pch.h"
#include <iostream>

using namespace std;

void swap_sort(int *a, int *b, int *c, bool order)
{
	int temp;
	for (int i = 0; i < 2; i++)
		if (order)
		{
			if (b < a)
			{
				temp = a;
				a = b;
				b = temp;
			}
			if (c < b)
			{
				temp = b;
				b = c;
				c = temp;
			}
		}
		else
		{
			if (c > b)
			{
				temp = b;
				b = c;
				c = temp;
			}
			if (b > a)
			{
				temp = a;
				a = b;
				b = temp;
			}
		}
}

int main()
{
     
}